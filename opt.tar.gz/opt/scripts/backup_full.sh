#!/bin/bash

# ===============================================
# SCRIPT: backup_full.sh
# UBICACION: /opt/scripts/backup_full.sh
# FUNCION: Realiza backups completos (full) de directorios.
# ===============================================

# Variables estáticas
LOG_FILE="/var/log/backup_full.log"
DATE_ANSI=$(date +%Y%m%d)

# -----------------------------------------------
# FUNCION DE AYUDA
# -----------------------------------------------
show_help() {
    echo "Uso: $0 [OPCION] [ORIGEN] [DESTINO]"
    echo ""
    echo "Realiza un backup de un directorio ORIGEN al directorio DESTINO, "
    echo "nombrando el archivo con la fecha en formato YYYYMMDD."
    echo ""
    echo "Opciones disponibles:"
    echo "  -help     Muestra esta ayuda."
    echo ""
    echo "Argumentos obligatorios:"
    echo "  ORIGEN    Ruta absoluta del directorio a backupear (ej: /var/log)"
    echo "  DESTINO   Ruta absoluta del directorio donde se guardará el backup (ej: /backup_dir)"
    echo ""
    echo "Ejemplo: $0 /var/log /backup_dir"
}

# -----------------------------------------------
# FUNCION DE VALIDACION DE MONTAJE
# -----------------------------------------------
check_mount() {
    local dir=$1
S    if mountpoint -q "$dir"; then
        echo "Validación OK: El directorio '$dir' está montado correctamente." | tee -a "$LOG_FILE"
        return 0
    else
        echo "Error de Validación: El directorio '$dir' NO está montado o no existe." | tee -a "$LOG_FILE"
        return 1
    fi
}

# -----------------------------------------------
# MANEJO DE ARGUMENTOS
# -----------------------------------------------

# Opción de ayuda
if [ "$1" == "-help" ]; then
    show_help
    exit 0
fi

# Validar número de argumentos
if [ "$#" -ne 2 ]; then
    echo "Error: Se requieren dos argumentos (ORIGEN y DESTINO)." | tee -a "$LOG_FILE"
    show_help
    exit 1
fi

SOURCE_DIR=$1
DEST_DIR=$2

# Validar que el ORIGEN sea un directorio
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: El ORIGEN ($SOURCE_DIR) no es un directorio válido." | tee -a "$LOG_FILE"
    exit 1
fi

# -----------------------------------------------
# EJECUCION DEL BACKUP
# -----------------------------------------------

# 1. Validar si los sistemas de archivos están disponibles
if check_mount "$SOURCE_DIR" && check_mount "$DEST_DIR"; then
    # 2. Definir el nombre del archivo de backup
    BASE_NAME=$(basename "$SOURCE_DIR")
    ARCHIVE_NAME="${BASE_NAME}_bkp_${DATE_ANSI}.tar.gz"
    FULL_PATH="${DEST_DIR}/${ARCHIVE_NAME}"

    echo "--- Iniciando backup de $SOURCE_DIR a $FULL_PATH ---" | tee -a "$LOG_FILE"

    # 3. Crear el backup
    if tar -czf "$FULL_PATH" -C "$(dirname "$SOURCE_DIR")" "$BASE_NAME"; then
        echo "Backup exitoso: $ARCHIVE_NAME" | tee -a "$LOG_FILE"
    else
        echo "Error: Falló la creación del backup TAR." | tee -a "$LOG_FILE"
        exit 2
    fi
else
    echo "Error: El backup no se ejecutó debido a fallos en la validación de montaje." | tee -a "$LOG_FILE"
    exit 3
fi

exit 0
